puts " Ecrire un nombre"
nombre =gets.chomp.to_i

nombre.times do |i|
    puts "#{i}"
end