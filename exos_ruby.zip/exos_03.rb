puts "Bonjour monde !"
#print "Et avec une voix sexy, ça donne : Bonjour, monde !" ( ceci est un commentaire)