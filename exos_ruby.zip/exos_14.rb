puts " Ecrire un nombre"
nombre = gets.to_i
i = 0
while nombre >= i
    puts nombre = nombre - 1
   
end