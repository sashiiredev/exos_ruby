# On decalre les variables et chaque variables reçoient une valeur

number_of_hours_worked_per_day = 10
number_of_days_worked_per_week = 5
number_of_weeks_in_THP = 11
# On demande d'afficher le calcul des valeurs de chaque variables en prennant de chaque variables
puts "Travail : #{number_of_hours_worked_per_day * number_of_days_worked_per_week * number_of_weeks_in_THP}"
#la variables "number_of_linutes_in_an_hour n'est pas déclarer initialement"
puts "Et en minutes ça fait : #{number_of_minutes_in_an_hour * number_of_hours_worked_per_day * number_of_days_worked_per_week * number_of_weeks_in_THP}"