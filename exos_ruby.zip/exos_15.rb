puts " Ecris ton année de naissance"
anneeDeNaissance =gets.to_i
anneeEnCours = 2019

while anneeDeNaissance < anneeEnCours
    puts "l'année #{anneeDeNaissance =anneeDeNaissance + 1}"
   if (anneeDeNaissance < anneeEnCours)
       puts " tu avais #{anneeEnCours - anneeDeNaissance} ans"
     end
end
