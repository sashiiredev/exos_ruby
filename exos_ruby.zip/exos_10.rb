puts " Quel est ton année de naissance ?"
user_age = gets.chomp.to_i
annee_en_cours =2017
puts "tu as #{annee_en_cours - user_age}"