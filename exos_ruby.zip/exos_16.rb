puts " Quel est ton age"
age = gets.to_i
anneeEnCours = 2019
anneeDeNaissance = anneeEnCours - age
while (anneeDeNaissance <= anneeEnCours)
    puts age = age - 1
    puts "Il y a #{anneeEnCours - anneeDeNaissance} ans,"

end