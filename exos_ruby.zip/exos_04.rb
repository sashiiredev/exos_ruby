puts "Salut, ça farte ?
#Il y a une erreur car il manque les guillemets