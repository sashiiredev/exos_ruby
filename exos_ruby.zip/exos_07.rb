puts "Bonjour, c'est quoi ton blase ?"
user_name = gets.chomp    #l'ordinateur attend une saisie de clavier d'une chaine
puts " salut " + user_name + " comment-tu vas !"