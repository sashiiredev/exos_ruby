puts " Ecrire un nombre"
nombre =gets.chomp.to_i

nombre.times do
    puts "Salut, ça farte"
end