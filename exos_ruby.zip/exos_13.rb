
puts " Ecrire ton année de naissance"
anneeDeNaissance =gets.chomp.to_i
anneeEnCours = 2019
while (anneeDeNaissance <= anneeEnCours)
    puts anneeDeNaissance
    anneeDeNaissance = anneeDeNaissance + 1
end